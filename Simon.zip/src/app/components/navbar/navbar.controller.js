'use strict';

angular.module('simon')
  .controller('NavbarCtrl', function ($scope) {
    $scope.date = new Date();
  });
